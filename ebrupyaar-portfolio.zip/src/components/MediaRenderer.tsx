import React, { useEffect, useMemo, useState } from 'react';
import { ExternalLink, Film, Play } from 'lucide-react';
import { FALLBACK_PROJECT_ART } from '../data/portfolioData';
import {
  getAspectContainerClass,
  parseMediaUrl,
  type MediaAspect,
  type ResolvedAspect,
} from '../utils/media';

interface TikTokOEmbedMeta {
  thumbnailUrl?: string;
  videoId?: string;
  title?: string;
}

const tiktokMetaCache = new Map<string, TikTokOEmbedMeta | null>();

function useTikTokOEmbed(url: string, enabled: boolean): TikTokOEmbedMeta | null {
  const [meta, setMeta] = useState<TikTokOEmbedMeta | null>(() =>
    enabled ? tiktokMetaCache.get(url) ?? null : null
  );

  useEffect(() => {
    if (!enabled || !url) return;
    if (tiktokMetaCache.has(url)) {
      setMeta(tiktokMetaCache.get(url) ?? null);
      return;
    }

    let cancelled = false;
    fetch(`https://www.tiktok.com/oembed?url=${encodeURIComponent(url)}`)
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (cancelled) return;
        if (!data) {
          tiktokMetaCache.set(url, null);
          return;
        }
        const htmlIdMatch =
          typeof data.html === 'string'
            ? data.html.match(/data-video-id="(\d+)"/)
            : null;
        const resolved: TikTokOEmbedMeta = {
          thumbnailUrl:
            typeof data.thumbnail_url === 'string' ? data.thumbnail_url : undefined,
          videoId:
            typeof data.embed_product_id === 'string' && /^\d+$/.test(data.embed_product_id)
              ? data.embed_product_id
              : htmlIdMatch?.[1],
          title: typeof data.title === 'string' ? data.title : undefined,
        };
        tiktokMetaCache.set(url, resolved);
        setMeta(resolved);
      })
      .catch(() => {
        if (!cancelled) {
          tiktokMetaCache.set(url, null);
        }
      });

    return () => {
      cancelled = true;
    };
  }, [url, enabled]);

  return meta;
}

function getCardInnerFrameClass(aspect: ResolvedAspect): string {
  switch (aspect) {
    case '9:16':
      return 'h-full aspect-[9/16] mx-auto rounded-lg overflow-hidden shadow-lg ring-1 ring-white/20';
    case '1:1':
      return 'h-full aspect-square mx-auto rounded-lg overflow-hidden shadow-md ring-1 ring-white/15';
    case '4:5':
      return 'h-full aspect-[4/5] mx-auto rounded-lg overflow-hidden shadow-md ring-1 ring-white/15';
    case '16:9':
    default:
      return 'w-full h-full';
  }
}

interface MediaCardPreviewProps {
  url: string;
  title: string;
  mediaAspect?: MediaAspect;
}

export const MediaCardPreview: React.FC<MediaCardPreviewProps> = ({
  url,
  title,
  mediaAspect = 'auto',
}) => {
  const parsed = useMemo(
    () => parseMediaUrl(url, mediaAspect),
    [url, mediaAspect]
  );
  const tiktokMeta = useTikTokOEmbed(
    parsed.normalizedUrl,
    parsed.kind === 'tiktok'
  );
  const [imgFailed, setImgFailed] = useState(false);

  useEffect(() => {
    setImgFailed(false);
  }, [url]);

  const effectiveThumb =
    parsed.kind === 'tiktok'
      ? tiktokMeta?.thumbnailUrl || null
      : parsed.thumbnailUrl;

  const isFramedBackdrop = parsed.aspect !== '16:9' || parsed.isVideo;

  return (
    <div
      className={`aspect-video overflow-hidden relative flex items-center justify-center ${
        isFramedBackdrop
          ? 'bg-slate-950'
          : 'bg-slate-100 dark:bg-slate-900'
      }`}
    >
      <div className={`${getCardInnerFrameClass(parsed.aspect)} relative overflow-hidden`}>
        {parsed.kind === 'video' ? (
          <video
            src={parsed.normalizedUrl}
            muted
            playsInline
            preload="metadata"
            className="w-full h-full object-cover"
          />
        ) : effectiveThumb && !imgFailed ? (
          <img
            src={effectiveThumb}
            alt={title}
            referrerPolicy="no-referrer"
            onError={() => setImgFailed(true)}
            className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
          />
        ) : parsed.isVideo ? (
          <div className="w-full h-full bg-gradient-to-br from-[#1B1340] via-[#311B7E] to-[#6D4AFF] flex flex-col items-center justify-center p-3 text-center">
            <Film className="w-7 h-7 text-purple-200 mb-1.5" />
            <span className="text-[11px] font-bold text-white tracking-wide">
              {parsed.platformLabel}
            </span>
            <span className="text-[10px] text-purple-200 mt-0.5 tabular-nums">
              {parsed.aspect}
            </span>
          </div>
        ) : (
          <img
            src={FALLBACK_PROJECT_ART}
            alt={title}
            className="w-full h-full object-cover"
          />
        )}
      </div>

      {/* Play button overlay for all video items */}
      {parsed.isVideo && (
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center bg-slate-950/20 group-hover:bg-slate-950/35 transition">
          <div className="w-12 h-12 rounded-full bg-white/95 text-primary shadow-xl flex items-center justify-center group-hover:scale-110 transition">
            <Play className="w-5 h-5 fill-current ml-0.5" />
          </div>
        </div>
      )}

      {/* Subtle aspect/platform indicator on card bottom-right for videos or custom non-16:9 sizes */}
      {(parsed.isVideo || parsed.aspect !== '16:9') && (
        <span className="pointer-events-none absolute bottom-2.5 right-2.5 px-2 py-0.5 rounded-md bg-slate-950/80 text-white text-[10px] font-semibold tabular-nums backdrop-blur-sm">
          {parsed.isVideo ? `${parsed.platformLabel} · ${parsed.aspect}` : parsed.aspect}
        </span>
      )}
    </div>
  );
};

interface MediaLightboxPlayerProps {
  url: string;
  title: string;
  mediaAspect?: MediaAspect;
}

export const MediaLightboxPlayer: React.FC<MediaLightboxPlayerProps> = ({
  url,
  title,
  mediaAspect = 'auto',
}) => {
  const parsed = useMemo(
    () => parseMediaUrl(url, mediaAspect),
    [url, mediaAspect]
  );
  const tiktokMeta = useTikTokOEmbed(
    parsed.normalizedUrl,
    parsed.kind === 'tiktok'
  );
  const [imgFailed, setImgFailed] = useState(false);

  useEffect(() => {
    setImgFailed(false);
  }, [url]);

  const resolvedTikTokId = parsed.videoId || tiktokMeta?.videoId;
  const resolvedEmbedUrl =
    parsed.kind === 'tiktok' && resolvedTikTokId
      ? `https://www.tiktok.com/player/v1/${resolvedTikTokId}?autoplay=1&music_info=1&description=1&rel=0`
      : parsed.embedUrl;

  const containerClass = getAspectContainerClass(parsed.aspect);

  if (parsed.kind === 'video') {
    return (
      <div className="rounded-2xl overflow-hidden bg-slate-950 p-2 sm:p-3 flex items-center justify-center">
        <div className={`${containerClass} rounded-xl overflow-hidden bg-black`}>
          <video
            key={parsed.normalizedUrl}
            src={parsed.normalizedUrl}
            controls
            autoPlay
            playsInline
            className="w-full h-full object-contain"
          />
        </div>
      </div>
    );
  }

  if (resolvedEmbedUrl) {
    return (
      <div className="rounded-2xl overflow-hidden bg-slate-950 p-2 sm:p-3 flex flex-col items-center justify-center">
        <div className={`${containerClass} rounded-xl overflow-hidden bg-black shadow-2xl`}>
          <iframe
            key={resolvedEmbedUrl}
            className="w-full h-full border-0"
            src={resolvedEmbedUrl}
            title={title}
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            allowFullScreen
          />
        </div>
        <div className="mt-2.5 flex items-center justify-between w-full px-1 text-[11px] text-slate-400">
          <span>
            {parsed.platformLabel} · {parsed.aspect}
          </span>
          <a
            href={parsed.normalizedUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center space-x-1 text-purple-300 hover:text-white transition font-medium"
          >
            <span>Open Original</span>
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>
      </div>
    );
  }

  // TikTok short link fallback (e.g. vm.tiktok.com when oEmbed ID isn't available)
  if (parsed.kind === 'tiktok') {
    return (
      <div className="rounded-2xl overflow-hidden bg-slate-950 p-4 flex flex-col items-center justify-center">
        <div
          className={`${containerClass} rounded-xl overflow-hidden bg-gradient-to-br from-[#1B1340] via-[#311B7E] to-[#6D4AFF] relative flex flex-col items-center justify-center text-center p-6`}
        >
          {tiktokMeta?.thumbnailUrl && (
            <img
              src={tiktokMeta.thumbnailUrl}
              alt={title}
              referrerPolicy="no-referrer"
              className="absolute inset-0 w-full h-full object-cover opacity-50"
            />
          )}
          <div className="relative z-10 flex flex-col items-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-white text-primary flex items-center justify-center shadow-xl">
              <Play className="w-7 h-7 fill-current ml-0.5" />
            </div>
            <p className="text-xs text-white/90 font-medium max-w-[220px]">
              Short TikTok links open directly on TikTok. Use a full TikTok video URL (containing /video/ID) for inline playback.
            </p>
            <a
              href={parsed.normalizedUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center space-x-2 px-5 py-2.5 rounded-xl bg-primary text-white text-xs font-bold hover:bg-primary-dark transition shadow-lg"
            >
              <span>Watch on TikTok</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>
      </div>
    );
  }

  // Standard image rendering (respecting explicit aspect if selected, or natural fit on auto)
  if (mediaAspect !== 'auto') {
    return (
      <div className="rounded-2xl overflow-hidden bg-slate-950 p-2 sm:p-3 flex items-center justify-center">
        <div className={`${containerClass} rounded-xl overflow-hidden bg-slate-900`}>
          <img
            src={imgFailed ? FALLBACK_PROJECT_ART : parsed.normalizedUrl}
            alt={title}
            referrerPolicy="no-referrer"
            onError={() => setImgFailed(true)}
            className="w-full h-full object-cover"
          />
        </div>
      </div>
    );
  }

  return (
    <div className="rounded-2xl overflow-hidden bg-slate-900 max-h-[65vh] flex items-center justify-center">
      <img
        src={imgFailed ? FALLBACK_PROJECT_ART : parsed.normalizedUrl}
        alt={title}
        referrerPolicy="no-referrer"
        onError={() => setImgFailed(true)}
        className="w-full h-auto object-contain max-h-[65vh]"
      />
    </div>
  );
};
