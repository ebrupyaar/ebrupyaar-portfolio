import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertCircle,
  CheckCircle2,
  Lock,
  ShieldCheck,
  X,
} from 'lucide-react';
import {
  ADMIN_PIN,
  FALLBACK_PROJECT_ART,
  PROJECT_CATEGORIES,
  type Project,
  type ProjectCategory,
  type TranslationDict,
} from '../data/portfolioData';
import {
  normalizeMediaUrl,
  parseMediaUrl,
  type MediaAspect,
} from '../utils/media';
import { MediaCardPreview, MediaLightboxPlayer } from './MediaRenderer';

/* ---------------- TOAST NOTIFICATION ---------------- */
interface ToastProps {
  visible: boolean;
  message: string;
  isError?: boolean;
}

export const ToastNotification: React.FC<ToastProps> = ({
  visible,
  message,
  isError = false,
}) => {
  return (
    <div
      role="status"
      aria-live="polite"
      className={`fixed bottom-5 right-5 z-50 transform transition-all duration-300 pointer-events-none ${
        visible ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0'
      }`}
    >
      <div className="bg-slate-900 dark:bg-white text-white dark:text-slate-900 px-5 py-3 rounded-2xl shadow-xl flex items-center space-x-3 text-sm font-medium border border-slate-700 dark:border-slate-200">
        {isError ? (
          <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
        ) : (
          <CheckCircle2 className="w-4 h-4 text-emerald-400 dark:text-emerald-600 shrink-0" />
        )}
        <span>{message}</span>
      </div>
    </div>
  );
};

/* ---------------- 6-DIGIT PIN VERIFICATION MODAL ---------------- */
interface PinModalProps {
  isOpen: boolean;
  t: TranslationDict;
  onClose: () => void;
  onSuccess: () => void;
}

export const PinModal: React.FC<PinModalProps> = ({
  isOpen,
  t,
  onClose,
  onSuccess,
}) => {
  const [pin, setPin] = useState('');
  const [error, setError] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setPin('');
      setError(false);
      const timer = setTimeout(() => inputRef.current?.focus(), 100);
      return () => clearTimeout(timer);
    }
  }, [isOpen]);

  useEffect(() => {
    if (!isOpen) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (pin.trim() === ADMIN_PIN) {
      onSuccess();
    } else {
      setError(true);
      setPin('');
      inputRef.current?.focus();
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="bg-white dark:bg-darkCard rounded-3xl max-w-sm w-full p-7 shadow-2xl relative border border-slate-100 dark:border-slate-800 text-center">
        <button
          type="button"
          onClick={onClose}
          aria-label="Close PIN modal"
          className="absolute top-4 right-4 w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-500 flex items-center justify-center hover:bg-slate-200 dark:hover:bg-slate-700 transition cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="w-14 h-14 rounded-2xl bg-purple-100 dark:bg-purple-950 text-primary mx-auto flex items-center justify-center mb-4">
          <ShieldCheck className="w-7 h-7" />
        </div>
        <h3 className="text-xl font-extrabold text-slate-900 dark:text-white">
          {t.pinTitle}
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 mb-5">
          {t.pinSubtitle}
        </p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <input
            ref={inputRef}
            type="password"
            maxLength={6}
            inputMode="numeric"
            pattern="[0-9]{6}"
            required
            value={pin}
            onChange={(e) => {
              setPin(e.target.value);
              if (error) setError(false);
            }}
            placeholder="••••••"
            className="w-full text-center tracking-[0.6em] text-2xl font-extrabold px-4 py-3.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-primary focus:outline-none tabular-nums"
          />
          {error && (
            <p className="text-xs font-semibold text-rose-500">
              Incorrect 6-digit PIN. Please try again.
            </p>
          )}
          <button
            type="submit"
            className="w-full py-3 rounded-xl bg-primary text-white font-bold text-sm hover:bg-primary-dark transition shadow-lg shadow-primary/25 cursor-pointer"
          >
            {t.pinSubmit}
          </button>
        </form>
      </div>
    </div>
  );
};

/* ---------------- ADMIN UPLOAD MODAL ---------------- */
const ASPECT_OPTIONS: { value: MediaAspect; label: string }[] = [
  { value: 'auto', label: 'Auto-Detect' },
  { value: '16:9', label: 'YouTube (16:9)' },
  { value: '9:16', label: 'TikTok / Shorts (9:16)' },
  { value: '1:1', label: 'Square (1:1)' },
  { value: '4:5', label: 'Portrait (4:5)' },
];

interface AdminUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLock: () => void;
  onPublish: (project: Omit<Project, 'id'>) => void;
}

export const AdminUploadModal: React.FC<AdminUploadModalProps> = ({
  isOpen,
  onClose,
  onLock,
  onPublish,
}) => {
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<ProjectCategory>('Photoshop');
  const [urlInput, setUrlInput] = useState('');
  const [uploadedDataUrl, setUploadedDataUrl] = useState('');
  const [mediaAspect, setMediaAspect] = useState<MediaAspect>('auto');
  const [desc, setDesc] = useState('');
  const [fileWarning, setFileWarning] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!isOpen) {
      setTitle('');
      setCategory('Photoshop');
      setUrlInput('');
      setUploadedDataUrl('');
      setMediaAspect('auto');
      setDesc('');
      setFileWarning('');
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  }, [isOpen]);

  useEffect(() => {
    if (!isOpen) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [isOpen, onClose]);

  const previewRawUrl = uploadedDataUrl || urlInput.trim();
  const parsedPreview = useMemo(
    () => (previewRawUrl ? parseMediaUrl(previewRawUrl, mediaAspect) : null),
    [previewRawUrl, mediaAspect]
  );

  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setFileWarning('');
    if (file.size > 3.5 * 1024 * 1024) {
      setFileWarning(
        'Large file detected (>3.5 MB). Browser storage may be limited; for videos, pasting a YouTube/TikTok/MP4 URL is recommended.'
      );
    }
    const reader = new FileReader();
    reader.onload = (ev) => {
      if (typeof ev.target?.result === 'string') {
        setUploadedDataUrl(ev.target.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const normalizedInput = normalizeMediaUrl(urlInput);
    const finalUrl = uploadedDataUrl || normalizedInput || FALLBACK_PROJECT_ART;
    onPublish({
      title: title.trim(),
      category,
      url: finalUrl,
      desc: desc.trim(),
      mediaAspect,
    });
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="bg-white dark:bg-darkCard rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl relative border border-slate-100 dark:border-slate-800 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800 mb-6">
          <div>
            <h3 className="text-xl font-bold text-slate-900 dark:text-white">
              Ebrupyaar Admin Upload
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Add new creative image or video project.
            </p>
          </div>
          <div className="flex items-center space-x-2">
            <button
              type="button"
              onClick={onLock}
              title="Lock Admin Session"
              className="px-3 py-1.5 rounded-xl bg-rose-50 dark:bg-rose-950/50 text-rose-600 dark:text-rose-400 text-xs font-bold hover:bg-rose-100 dark:hover:bg-rose-900/50 transition flex items-center space-x-1 cursor-pointer"
            >
              <Lock className="w-3 h-3" />
              <span>Lock</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              aria-label="Close Admin Modal"
              className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-500 flex items-center justify-center hover:bg-slate-200 dark:hover:bg-slate-700 transition cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label
              htmlFor="proj-title"
              className="block text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase mb-1"
            >
              Project Title
            </label>
            <input
              id="proj-title"
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g., Motion Showreel or Brand Identity"
              className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-primary focus:outline-none text-sm"
            />
          </div>

          <div>
            <label
              htmlFor="proj-category"
              className="block text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase mb-1"
            >
              Software / Service Category
            </label>
            <select
              id="proj-category"
              value={category}
              onChange={(e) => setCategory(e.target.value as ProjectCategory)}
              className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-primary focus:outline-none text-sm"
            >
              {PROJECT_CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label
              htmlFor="proj-file"
              className="block text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase mb-1"
            >
              Upload Image or Video File (Optional)
            </label>
            <input
              ref={fileInputRef}
              id="proj-file"
              type="file"
              accept="image/*,video/*"
              onChange={handleFileChange}
              className="w-full text-xs text-slate-500 file:mr-4 file:py-2.5 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-purple-50 dark:file:bg-purple-950 file:text-primary hover:file:bg-purple-100 cursor-pointer"
            />
            {fileWarning && (
              <p className="text-[11px] text-amber-600 dark:text-amber-400 mt-1">
                {fileWarning}
              </p>
            )}
          </div>

          <div>
            <label
              htmlFor="proj-url"
              className="block text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase mb-1"
            >
              Or Image / Video Link URL
            </label>
            <input
              id="proj-url"
              type="text"
              value={urlInput}
              onChange={(e) => setUrlInput(e.target.value)}
              placeholder="YouTube, Shorts, TikTok, Vimeo, Instagram, MP4, or Image URL"
              className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-primary focus:outline-none text-sm"
            />
            <span className="text-[11px] text-slate-400 mt-1 block">
              Supports YouTube, YouTube Shorts, TikTok, Vimeo, Instagram Reels, Google Drive, direct MP4, and image links.
            </span>
          </div>

          {/* Display Size / Aspect Selector */}
          <div>
            <span className="block text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase mb-1.5">
              Display Size / Aspect Format
            </span>
            <div className="flex flex-wrap gap-1.5">
              {ASPECT_OPTIONS.map((opt) => (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() => setMediaAspect(opt.value)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition whitespace-nowrap shrink-0 cursor-pointer ${
                    mediaAspect === opt.value
                      ? 'bg-primary text-white shadow-sm'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-purple-50 dark:hover:bg-slate-700'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Live Media Preview */}
          {parsedPreview && (
            <div className="rounded-2xl border border-slate-200 dark:border-slate-700 overflow-hidden bg-slate-50 dark:bg-slate-900/80 p-3 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-700 dark:text-slate-200">
                  Live Preview
                </span>
                <span className="text-primary dark:text-purple-300 font-bold tabular-nums">
                  {parsedPreview.platformLabel} · {parsedPreview.aspect}
                </span>
              </div>
              <div className="rounded-xl overflow-hidden">
                <MediaCardPreview
                  url={previewRawUrl}
                  title={title || 'Preview'}
                  mediaAspect={mediaAspect}
                />
              </div>
              {parsedPreview.kind === 'tiktok' && !parsedPreview.videoId && (
                <p className="text-[11px] text-amber-600 dark:text-amber-400">
                  Tip: Paste a full TikTok URL (e.g. https://www.tiktok.com/@user/video/1234567890) for inline playback.
                </p>
              )}
            </div>
          )}

          <div>
            <label
              htmlFor="proj-desc"
              className="block text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase mb-1"
            >
              Description
            </label>
            <textarea
              id="proj-desc"
              rows={3}
              required
              value={desc}
              onChange={(e) => setDesc(e.target.value)}
              placeholder="Describe the design concept and tools used..."
              className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-primary focus:outline-none text-sm"
            />
          </div>

          <div className="pt-4 flex items-center justify-end space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 text-sm font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 text-sm font-semibold bg-primary text-white rounded-xl hover:bg-primary-dark transition shadow-lg shadow-primary/25 cursor-pointer"
            >
              Publish Project
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

/* ---------------- LIGHTBOX MODAL ---------------- */
interface LightboxModalProps {
  project: Project | null;
  onClose: () => void;
}

export const LightboxModal: React.FC<LightboxModalProps> = ({
  project,
  onClose,
}) => {
  useEffect(() => {
    if (!project) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [project, onClose]);

  if (!project) return null;

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="bg-white dark:bg-darkCard rounded-3xl max-w-3xl w-full p-6 sm:p-8 shadow-2xl relative border border-slate-100 dark:border-slate-800 max-h-[92vh] overflow-y-auto">
        <button
          type="button"
          onClick={onClose}
          aria-label="Close Lightbox"
          className="absolute top-4 right-4 w-9 h-9 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 flex items-center justify-center hover:bg-slate-200 dark:hover:bg-slate-700 transition z-10 cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="space-y-4">
          <div className="flex items-center space-x-2 text-xs font-semibold">
            <span className="text-primary dark:text-purple-300 font-bold">
              {project.category}
            </span>
            <span
              aria-hidden="true"
              className="text-slate-300 dark:text-slate-600"
            >
              ·
            </span>
            <span className="text-slate-400">@ebrupyaar</span>
          </div>
          <h2 className="text-2xl font-bold text-slate-900 dark:text-white pr-8">
            {project.title}
          </h2>
          <MediaLightboxPlayer
            url={project.url}
            title={project.title}
            mediaAspect={project.mediaAspect}
          />
          <p className="text-slate-600 dark:text-slate-300 text-sm leading-relaxed pt-2">
            {project.desc}
          </p>
        </div>
      </div>
    </div>
  );
};
