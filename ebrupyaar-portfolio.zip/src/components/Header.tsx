import React, { useState } from 'react';
import { Globe, Lock, LockOpen, Menu, Moon, PenTool, Sun, X } from 'lucide-react';
import type { Language, Theme, TranslationDict } from '../data/portfolioData';

interface HeaderProps {
  t: TranslationDict;
  lang: Language;
  theme: Theme;
  isAdminUnlocked: boolean;
  onToggleLanguage: () => void;
  onToggleTheme: () => void;
  onAdminClick: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  t,
  lang,
  theme,
  isAdminUnlocked,
  onToggleLanguage,
  onToggleTheme,
  onAdminClick,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { href: '#portfolio', label: t.navPortfolio },
    { href: '#skills', label: t.navTools },
    { href: '#about', label: t.navAbout },
    { href: '#contact', label: t.navContact },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white/85 dark:bg-darkBg/85 backdrop-blur-md border-b border-purple-100/80 dark:border-slate-800 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-4 sm:gap-8">
        {/* Brand Logo */}
        <a href="#" className="flex items-center space-x-3 group shrink-0">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-primary to-purple-400 flex items-center justify-center text-white font-bold shadow-lg shadow-primary/25 group-hover:scale-105 transition">
            <PenTool className="w-5 h-5" />
          </div>
          <div>
            <span className="font-extrabold text-base sm:text-lg tracking-tight text-slate-900 dark:text-white block whitespace-nowrap">
              Ebrupyaar
            </span>
            <span className="text-[11px] font-medium text-primary dark:text-purple-300 block whitespace-nowrap">
              {t.brandSub}
            </span>
          </div>
        </a>

        {/* Desktop Nav Links */}
        <nav className="hidden lg:flex items-center space-x-8 text-sm font-semibold text-slate-600 dark:text-slate-300">
          {navItems.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="hover:text-primary transition whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary rounded-md px-1 py-0.5"
            >
              {item.label}
            </a>
          ))}
        </nav>

        {/* Action Controls: Language, Theme, Admin */}
        <div className="flex items-center space-x-1.5 sm:space-x-3 shrink-0">
          {/* Language Switcher (EN | አማ) */}
          <button
            type="button"
            onClick={onToggleLanguage}
            title="Switch Language"
            className="px-2.5 sm:px-3 py-2 text-xs font-bold rounded-xl bg-purple-50 dark:bg-slate-800 text-primary dark:text-purple-300 border border-purple-200/70 dark:border-slate-700 hover:bg-purple-100 dark:hover:bg-slate-700 transition flex items-center space-x-1.5 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
          >
            <Globe className="w-3.5 h-3.5 shrink-0" />
            <span>{lang === 'en' ? 'EN | አማ' : 'አማ | EN'}</span>
          </button>

          {/* Dark / Light Mode Toggle */}
          <button
            type="button"
            onClick={onToggleTheme}
            title="Toggle Dark/Light Mode"
            aria-label="Toggle Dark/Light Mode"
            className="w-9 h-9 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-amber-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-200 dark:hover:bg-slate-700 transition flex items-center justify-center shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
          >
            {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>

          {/* PIN-Protected Admin Button */}
          <button
            type="button"
            onClick={onAdminClick}
            className="px-3 sm:px-4 py-2 text-xs sm:text-sm font-semibold bg-primary text-white rounded-xl hover:bg-primary-dark transition shadow-md shadow-primary/20 flex items-center space-x-1.5 sm:space-x-2 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 dark:focus-visible:ring-offset-darkBg"
          >
            {isAdminUnlocked ? (
              <LockOpen className="w-3.5 h-3.5 text-emerald-300 shrink-0" />
            ) : (
              <Lock className="w-3.5 h-3.5 shrink-0" />
            )}
            <span>{t.navAdmin}</span>
          </button>

          {/* Mobile Menu Toggle */}
          <button
            type="button"
            onClick={() => setMobileMenuOpen((prev) => !prev)}
            aria-label="Toggle Mobile Menu"
            aria-expanded={mobileMenuOpen}
            className="lg:hidden w-9 h-9 rounded-xl bg-purple-50 dark:bg-slate-800 text-primary dark:text-purple-300 border border-purple-200/70 dark:border-slate-700 flex items-center justify-center shrink-0 cursor-pointer"
          >
            {mobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Mobile Dropdown Navigation */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white/95 dark:bg-darkCard/95 backdrop-blur-md border-t border-purple-100 dark:border-slate-800 px-4 py-4 space-y-2 shadow-lg">
          {navItems.map((item) => (
            <a
              key={item.href}
              href={item.href}
              onClick={() => setMobileMenuOpen(false)}
              className="block px-4 py-2.5 rounded-xl text-sm font-semibold text-slate-700 dark:text-slate-200 hover:bg-purple-50 dark:hover:bg-slate-800 transition"
            >
              {item.label}
            </a>
          ))}
        </div>
      )}
    </header>
  );
};
