export type MediaAspect = 'auto' | '16:9' | '9:16' | '1:1' | '4:5';
export type ResolvedAspect = '16:9' | '9:16' | '1:1' | '4:5';
export type MediaKind =
  | 'youtube'
  | 'tiktok'
  | 'vimeo'
  | 'instagram'
  | 'facebook'
  | 'gdrive'
  | 'video'
  | 'image';

export interface ParsedMedia {
  kind: MediaKind;
  normalizedUrl: string;
  embedUrl: string | null;
  thumbnailUrl: string | null;
  aspect: ResolvedAspect;
  platformLabel: string;
  isVideo: boolean;
  videoId?: string;
}

export function normalizeMediaUrl(raw: string): string {
  const trimmed = raw.trim();
  if (!trimmed) return '';
  if (
    trimmed.startsWith('http://') ||
    trimmed.startsWith('https://') ||
    trimmed.startsWith('data:') ||
    trimmed.startsWith('/')
  ) {
    return trimmed;
  }
  if (/^[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}(\/|$)/.test(trimmed)) {
    return `https://${trimmed}`;
  }
  return trimmed;
}

export function extractYouTubeId(url: string): { id: string; isShort: boolean } | null {
  try {
    const parsed = new URL(url);
    const host = parsed.hostname.replace(/^www\./, '').toLowerCase();

    if (host === 'youtu.be') {
      const id = parsed.pathname.split('/').filter(Boolean)[0];
      if (id && id.length >= 11) {
        return { id: id.slice(0, 11), isShort: false };
      }
    }

    if (host === 'youtube.com' || host === 'm.youtube.com' || host === 'music.youtube.com') {
      const vParam = parsed.searchParams.get('v');
      if (vParam && vParam.length >= 11) {
        return { id: vParam.slice(0, 11), isShort: false };
      }

      const parts = parsed.pathname.split('/').filter(Boolean);
      if (parts.length >= 2 && ['shorts', 'embed', 'live', 'v'].includes(parts[0])) {
        const id = parts[1];
        if (id && id.length >= 11) {
          return { id: id.slice(0, 11), isShort: parts[0] === 'shorts' };
        }
      }
    }
  } catch {
    // Fall back to regex if URL parsing fails
  }

  const regExp =
    /^.*(?:youtu\.be\/|v\/|u\/\w\/|embed\/|shorts\/|live\/|watch\?v=|&v=)([A-Za-z0-9_-]{11}).*/;
  const match = url.match(regExp);
  if (match && match[1]) {
    return {
      id: match[1],
      isShort: /\/shorts\//i.test(url),
    };
  }
  return null;
}

export function extractTikTokId(url: string): string | null {
  const match = url.match(/tiktok\.com\/(?:@[^/]+\/video|embed\/v2|player\/v1|v)\/(\d+)/i);
  if (match && match[1]) return match[1];
  const fallbackMatch = url.match(/\/video\/(\d+)/i);
  return fallbackMatch?.[1] ?? null;
}

export function isTikTokUrl(url: string): boolean {
  return /(?:^|\.)tiktok\.com/i.test(url);
}

export function extractVimeoId(url: string): string | null {
  const match = url.match(/(?:player\.)?vimeo\.com\/(?:video\/)?(\d+)/i);
  return match?.[1] ?? null;
}

export function extractInstagramMatch(
  url: string
): { type: 'reel' | 'p'; code: string } | null {
  const match = url.match(/instagram\.com\/(reel|reels|p|tv)\/([A-Za-z0-9_-]+)/i);
  if (!match) return null;
  const rawType = match[1].toLowerCase();
  return {
    type: rawType === 'reel' || rawType === 'reels' ? 'reel' : 'p',
    code: match[2],
  };
}

export function extractGDriveId(url: string): string | null {
  const fileMatch = url.match(/drive\.google\.com\/file\/d\/([A-Za-z0-9_-]+)/i);
  if (fileMatch?.[1]) return fileMatch[1];
  const openMatch = url.match(/drive\.google\.com\/open\?id=([A-Za-z0-9_-]+)/i);
  return openMatch?.[1] ?? null;
}

export function isDirectVideoUrl(url: string): boolean {
  if (url.startsWith('data:video/')) return true;
  return /\.(mp4|webm|ogg|ogv|mov|m4v)(\?.*|#.*)?$/i.test(url);
}

export function parseMediaUrl(
  rawUrl: string,
  preferredAspect: MediaAspect = 'auto'
): ParsedMedia {
  const url = normalizeMediaUrl(rawUrl);

  const yt = extractYouTubeId(url);
  if (yt) {
    const defaultAspect: ResolvedAspect = yt.isShort ? '9:16' : '16:9';
    return {
      kind: 'youtube',
      normalizedUrl: url,
      embedUrl: `https://www.youtube.com/embed/${yt.id}?autoplay=1&rel=0&playsinline=1`,
      thumbnailUrl: `https://img.youtube.com/vi/${yt.id}/hqdefault.jpg`,
      aspect: preferredAspect === 'auto' ? defaultAspect : preferredAspect,
      platformLabel: yt.isShort ? 'YouTube Shorts' : 'YouTube',
      isVideo: true,
      videoId: yt.id,
    };
  }

  if (isTikTokUrl(url)) {
    const tiktokId = extractTikTokId(url);
    return {
      kind: 'tiktok',
      normalizedUrl: url,
      embedUrl: tiktokId
        ? `https://www.tiktok.com/player/v1/${tiktokId}?autoplay=1&music_info=1&description=1&rel=0`
        : null,
      thumbnailUrl: null,
      aspect: preferredAspect === 'auto' ? '9:16' : preferredAspect,
      platformLabel: 'TikTok',
      isVideo: true,
      videoId: tiktokId ?? undefined,
    };
  }

  const vimeoId = extractVimeoId(url);
  if (vimeoId) {
    return {
      kind: 'vimeo',
      normalizedUrl: url,
      embedUrl: `https://player.vimeo.com/video/${vimeoId}?autoplay=1`,
      thumbnailUrl: null,
      aspect: preferredAspect === 'auto' ? '16:9' : preferredAspect,
      platformLabel: 'Vimeo',
      isVideo: true,
      videoId: vimeoId,
    };
  }

  const ig = extractInstagramMatch(url);
  if (ig) {
    const defaultAspect: ResolvedAspect = ig.type === 'reel' ? '9:16' : '4:5';
    return {
      kind: 'instagram',
      normalizedUrl: url,
      embedUrl: `https://www.instagram.com/${ig.type}/${ig.code}/embed/`,
      thumbnailUrl: null,
      aspect: preferredAspect === 'auto' ? defaultAspect : preferredAspect,
      platformLabel: ig.type === 'reel' ? 'Instagram Reel' : 'Instagram',
      isVideo: ig.type === 'reel',
    };
  }

  if (/(?:facebook\.com\/.*\/videos\/|facebook\.com\/reel\/|facebook\.com\/watch|fb\.watch\/)/i.test(url)) {
    const isReel = /\/reel\//i.test(url);
    return {
      kind: 'facebook',
      normalizedUrl: url,
      embedUrl: `https://www.facebook.com/plugins/video.php?href=${encodeURIComponent(
        url
      )}&show_text=false&autoplay=true`,
      thumbnailUrl: null,
      aspect: preferredAspect === 'auto' ? (isReel ? '9:16' : '16:9') : preferredAspect,
      platformLabel: isReel ? 'Facebook Reel' : 'Facebook Video',
      isVideo: true,
    };
  }

  const gdriveId = extractGDriveId(url);
  if (gdriveId) {
    return {
      kind: 'gdrive',
      normalizedUrl: url,
      embedUrl: `https://drive.google.com/file/d/${gdriveId}/preview`,
      thumbnailUrl: null,
      aspect: preferredAspect === 'auto' ? '16:9' : preferredAspect,
      platformLabel: 'Google Drive',
      isVideo: true,
      videoId: gdriveId,
    };
  }

  if (isDirectVideoUrl(url)) {
    return {
      kind: 'video',
      normalizedUrl: url,
      embedUrl: null,
      thumbnailUrl: null,
      aspect: preferredAspect === 'auto' ? '16:9' : preferredAspect,
      platformLabel: 'Video',
      isVideo: true,
    };
  }

  return {
    kind: 'image',
    normalizedUrl: url,
    embedUrl: null,
    thumbnailUrl: url,
    aspect: preferredAspect === 'auto' ? '16:9' : preferredAspect,
    platformLabel: 'Image',
    isVideo: false,
  };
}

export function getAspectContainerClass(aspect: ResolvedAspect): string {
  switch (aspect) {
    case '9:16':
      return 'aspect-[9/16] w-full max-w-[340px] mx-auto';
    case '1:1':
      return 'aspect-square w-full max-w-[460px] mx-auto';
    case '4:5':
      return 'aspect-[4/5] w-full max-w-[400px] mx-auto';
    case '16:9':
    default:
      return 'aspect-video w-full';
  }
}
