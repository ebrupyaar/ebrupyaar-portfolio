import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowDown,
  ArrowRight,
  Box,
  ChevronDown,
  ChevronUp,
  Copy,
  FileSignature,
  FileText,
  Film,
  FolderOpen,
  PenTool,
  Send,
  Trash2,
} from 'lucide-react';
import { Header } from './components/Header';
import { MediaCardPreview } from './components/MediaRenderer';
import {
  AdminUploadModal,
  LightboxModal,
  PinModal,
  ToastNotification,
} from './components/Modals';
import { SocialIcon } from './components/SocialIcons';
import {
  ABOUT_STUDIO_ART,
  DEFAULT_PROJECTS,
  HERO_SHOWREEL_ART,
  INITIAL_VISIBLE_COUNT,
  PROJECT_CATEGORIES,
  SOCIAL_LINKS,
  STORAGE_LANG_KEY,
  STORAGE_PROJECTS_KEY,
  STORAGE_THEME_KEY,
  translations,
  type FilterCategory,
  type Language,
  type Project,
  type ProjectCategory,
  type Theme,
} from './data/portfolioData';
import { parseMediaUrl } from './utils/media';

function loadInitialProjects(): Project[] {
  try {
    const raw = localStorage.getItem(STORAGE_PROJECTS_KEY);
    if (!raw) return DEFAULT_PROJECTS;
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return DEFAULT_PROJECTS;

    const defaultMap = new Map(DEFAULT_PROJECTS.map((p) => [p.id, p]));
    return parsed.map((item: Project) => {
      const def = defaultMap.get(item.id);
      if (def && typeof item.url === 'string' && item.url.includes('placehold.co')) {
        return { ...item, url: def.url };
      }
      return item;
    });
  } catch {
    return DEFAULT_PROJECTS;
  }
}

export default function App() {
  const [projects, setProjects] = useState<Project[]>(loadInitialProjects);
  const [currentFilter, setCurrentFilter] = useState<FilterCategory>('All');
  const [showAllProjects, setShowAllProjects] = useState(false);
  const [isAdminUnlocked, setIsAdminUnlocked] = useState(false);
  const [pinModalOpen, setPinModalOpen] = useState(false);
  const [adminModalOpen, setAdminModalOpen] = useState(false);
  const [lightboxProject, setLightboxProject] = useState<Project | null>(null);

  const [lang, setLang] = useState<Language>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_LANG_KEY);
      return saved === 'am' ? 'am' : 'en';
    } catch {
      return 'en';
    }
  });

  const [theme, setTheme] = useState<Theme>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_THEME_KEY);
      return saved === 'dark' ? 'dark' : 'light';
    } catch {
      return 'light';
    }
  });

  const [toast, setToast] = useState<{
    visible: boolean;
    message: string;
    isError: boolean;
  }>({ visible: false, message: '', isError: false });

  const toastTimerRef = useRef<number | null>(null);

  const t = translations[lang];

  useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark');
    try {
      localStorage.setItem(STORAGE_THEME_KEY, theme);
    } catch {
      // Ignore storage errors
    }
  }, [theme]);

  useEffect(() => {
    document.documentElement.lang = lang;
    try {
      localStorage.setItem(STORAGE_LANG_KEY, lang);
    } catch {
      // Ignore storage errors
    }
  }, [lang]);

  const showToast = useCallback((message: string, isError = false) => {
    if (toastTimerRef.current !== null) {
      window.clearTimeout(toastTimerRef.current);
    }
    setToast({ visible: true, message, isError });
    toastTimerRef.current = window.setTimeout(() => {
      setToast((prev) => ({ ...prev, visible: false }));
    }, 3000);
  }, []);

  const persistProjects = useCallback(
    (nextProjects: Project[]) => {
      setProjects(nextProjects);
      try {
        localStorage.setItem(STORAGE_PROJECTS_KEY, JSON.stringify(nextProjects));
      } catch {
        showToast('Storage full! Try using an image URL instead.', true);
      }
    },
    [showToast]
  );

  const handleToggleLanguage = () => {
    setLang((prev) => (prev === 'en' ? 'am' : 'en'));
  };

  const handleToggleTheme = () => {
    setTheme((prev) => (prev === 'light' ? 'dark' : 'light'));
  };

  const handleAdminClick = () => {
    if (isAdminUnlocked) {
      setAdminModalOpen(true);
    } else {
      setPinModalOpen(true);
    }
  };

  const handlePinSuccess = () => {
    setIsAdminUnlocked(true);
    setPinModalOpen(false);
    setAdminModalOpen(true);
    showToast(lang === 'am' ? 'አድሚን ፓነል ተከፍቷል!' : 'Admin panel unlocked!');
  };

  const handleLockAdmin = () => {
    setIsAdminUnlocked(false);
    setAdminModalOpen(false);
    showToast(lang === 'am' ? 'አድሚን ፓነል ተቆልፏል።' : 'Admin session locked.');
  };

  const handlePublishProject = (newProj: Omit<Project, 'id'>) => {
    const created: Project = {
      id: `proj_${Date.now()}`,
      ...newProj,
    };
    persistProjects([created, ...projects]);
    setAdminModalOpen(false);
    showToast(
      lang === 'am'
        ? 'አዲስ ስራ በተሳካ ሁኔታ ተጭኗል!'
        : 'New project published to Ebrupyaar Portfolio!'
    );
  };

  const handleDeleteProject = (id: string) => {
    if (!isAdminUnlocked) return;
    persistProjects(projects.filter((p) => p.id !== id));
    showToast(lang === 'am' ? 'ፕሮጀክቱ ተሰርዟል።' : 'Project removed.');
  };

  const handleFilterChange = (category: FilterCategory) => {
    setCurrentFilter(category);
    setShowAllProjects(false);
  };

  const handleFilterAndScroll = (category: ProjectCategory) => {
    handleFilterChange(category);
    const portfolioEl = document.getElementById('portfolio');
    if (portfolioEl) {
      portfolioEl.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleCopyHandle = async () => {
    const handleText = '@ebrupyaar';
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(handleText);
      } else {
        const tempInput = document.createElement('input');
        tempInput.value = handleText;
        document.body.appendChild(tempInput);
        tempInput.select();
        document.execCommand('copy');
        document.body.removeChild(tempInput);
      }
      showToast(
        lang === 'am'
          ? '@ebrupyaar ተቀድቷል!'
          : 'Copied @ebrupyaar to clipboard!'
      );
    } catch {
      showToast('Could not copy handle.', true);
    }
  };

  const filteredItems = useMemo(
    () =>
      projects.filter(
        (p) => currentFilter === 'All' || p.category === currentFilter
      ),
    [projects, currentFilter]
  );

  const visibleItems = showAllProjects
    ? filteredItems
    : filteredItems.slice(0, INITIAL_VISIBLE_COUNT);

  const remainingCount = Math.max(
    0,
    filteredItems.length - INITIAL_VISIBLE_COUNT
  );

  const toolsCards: {
    category: ProjectCategory;
    title: string;
    subtitle: string;
    badge: React.ReactNode;
    badgeClass: string;
  }[] = [
    {
      category: 'Photoshop',
      title: 'Photoshop',
      subtitle: t.toolPs,
      badge: 'Ps',
      badgeClass: 'bg-blue-950 text-cyan-400',
    },
    {
      category: 'Illustrator',
      title: 'Illustrator',
      subtitle: t.toolAi,
      badge: 'Ai',
      badgeClass: 'bg-amber-950 text-amber-400',
    },
    {
      category: 'After Effects',
      title: 'After Effects',
      subtitle: t.toolAe,
      badge: 'Ae',
      badgeClass: 'bg-purple-950 text-purple-300',
    },
    {
      category: 'Premiere Pro',
      title: 'Premiere Pro',
      subtitle: t.toolPr,
      badge: 'Pr',
      badgeClass: 'bg-indigo-950 text-indigo-300',
    },
    {
      category: 'Blender',
      title: 'Blender 3D',
      subtitle: t.toolBlender,
      badge: <Box className="w-5 h-5" />,
      badgeClass: 'bg-orange-950 text-orange-400',
    },
    {
      category: 'Canva',
      title: 'Canva',
      subtitle: t.toolCanva,
      badge: 'Cn',
      badgeClass: 'bg-teal-950 text-teal-300',
    },
    {
      category: 'Figma',
      title: 'Figma',
      subtitle: t.toolFigma,
      badge: 'Fi',
      badgeClass: 'bg-rose-950 text-rose-400',
    },
    {
      category: 'CV Creator',
      title: t.toolCvTitle,
      subtitle: t.toolCv,
      badge: <FileSignature className="w-5 h-5" />,
      badgeClass: 'bg-emerald-950 text-emerald-400',
    },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-[#F9F8FF] text-slate-800 dark:bg-darkBg dark:text-slate-100 graphic-grid-bg transition-colors duration-300 selection:bg-primary selection:text-white relative overflow-x-hidden">
      {/* Decorative Graphic Design SVG Accents */}
      <div className="pointer-events-none fixed inset-0 overflow-hidden z-0 opacity-40 dark:opacity-25">
        <svg
          className="absolute -top-16 -left-16 w-96 h-96 text-primary/20 animate-float-slow"
          viewBox="0 0 200 200"
          fill="none"
          aria-hidden="true"
        >
          <circle
            cx="100"
            cy="100"
            r="78"
            stroke="currentColor"
            strokeWidth="1.5"
            strokeDasharray="6 6"
          />
          <rect
            x="65"
            y="65"
            width="70"
            height="70"
            rx="14"
            stroke="currentColor"
            strokeWidth="1.5"
            transform="rotate(15 100 100)"
          />
          <circle cx="100" cy="22" r="4" fill="currentColor" />
          <circle cx="178" cy="100" r="4" fill="currentColor" />
        </svg>
        <svg
          className="absolute bottom-10 -right-12 w-[28rem] h-[28rem] text-purple-500/20"
          viewBox="0 0 300 300"
          fill="none"
          aria-hidden="true"
        >
          <path
            d="M30 220 C 90 80, 210 240, 270 70"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
          />
          <line
            x1="30"
            y1="220"
            x2="90"
            y2="80"
            stroke="currentColor"
            strokeWidth="1"
            strokeDasharray="4 4"
          />
          <line
            x1="270"
            y1="70"
            x2="210"
            y2="240"
            stroke="currentColor"
            strokeWidth="1"
            strokeDasharray="4 4"
          />
          <rect x="86" y="76" width="8" height="8" fill="currentColor" />
          <rect x="206" y="236" width="8" height="8" fill="currentColor" />
          <circle
            cx="30"
            cy="220"
            r="5"
            stroke="currentColor"
            strokeWidth="2"
            fill="white"
          />
          <circle
            cx="270"
            cy="70"
            r="5"
            stroke="currentColor"
            strokeWidth="2"
            fill="white"
          />
        </svg>
      </div>

      <ToastNotification
        visible={toast.visible}
        message={toast.message}
        isError={toast.isError}
      />

      <Header
        t={t}
        lang={lang}
        theme={theme}
        isAdminUnlocked={isAdminUnlocked}
        onToggleLanguage={handleToggleLanguage}
        onToggleTheme={handleToggleTheme}
        onAdminClick={handleAdminClick}
      />

      <main className="flex-grow relative z-10">
        {/* HERO SECTION */}
        <section className="relative pt-12 pb-16 sm:pt-20 sm:pb-24 overflow-hidden">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
              {/* Hero Content */}
              <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
                <p className="text-xs font-bold tracking-wider uppercase text-primary dark:text-purple-300">
                  {t.heroBadge}
                </p>
                <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold text-slate-900 dark:text-white tracking-tight leading-tight [text-wrap:balance]">
                  <span>{t.heroTitle1}</span>
                  <br />
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary via-purple-500 to-indigo-500">
                    {t.heroTitle2}
                  </span>
                </h1>
                <p className="text-sm sm:text-lg text-slate-600 dark:text-slate-300 max-w-2xl mx-auto lg:mx-0 font-normal leading-relaxed">
                  {t.heroDesc}
                </p>

                <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start space-y-3 sm:space-y-0 sm:space-x-4 pt-2">
                  <a
                    href="#portfolio"
                    className="w-full sm:w-auto px-7 py-3.5 rounded-xl bg-primary text-white font-semibold shadow-lg shadow-primary/30 hover:bg-primary-dark transition text-center flex items-center justify-center space-x-2 text-sm sm:text-base whitespace-nowrap shrink-0"
                  >
                    <span>{t.btnViewWork}</span>
                    <ArrowDown className="w-4 h-4 shrink-0" />
                  </a>
                  <a
                    href="#contact"
                    className="w-full sm:w-auto px-7 py-3.5 rounded-xl bg-white dark:bg-darkCard text-slate-700 dark:text-slate-200 font-semibold border border-slate-200 dark:border-slate-700 hover:border-primary dark:hover:border-primary transition text-center flex items-center justify-center space-x-2 shadow-sm text-sm sm:text-base whitespace-nowrap shrink-0"
                  >
                    <Send className="w-4 h-4 text-primary shrink-0" />
                    <span>{t.btnHireMe}</span>
                  </a>
                </div>

                {/* Quick Hero Social Links (@ebrupyaar) */}
                <div className="flex items-center justify-center lg:justify-start space-x-3 pt-1">
                  {SOCIAL_LINKS.map((social) => (
                    <a
                      key={social.id}
                      href={social.href}
                      target="_blank"
                      rel="noopener noreferrer"
                      aria-label={social.ariaLabel}
                      className={`w-9 h-9 rounded-xl bg-white dark:bg-darkCard border border-slate-200/80 dark:border-slate-700 flex items-center justify-center text-slate-600 dark:text-slate-300 ${social.hoverTextClass} ${social.hoverBorderClass} transition shadow-sm`}
                    >
                      <SocialIcon id={social.id} className="w-4 h-4" />
                    </a>
                  ))}
                </div>

                {/* Mini Stats */}
                <div className="grid grid-cols-3 gap-3 sm:gap-4 pt-6 border-t border-slate-200/80 dark:border-slate-800 max-w-lg mx-auto lg:mx-0">
                  <div>
                    <h3 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white tabular-nums">
                      {projects.length}+
                    </h3>
                    <p className="text-[11px] sm:text-xs text-slate-500 dark:text-slate-400 font-medium">
                      {t.statProjects}
                    </p>
                  </div>
                  <div>
                    <h3 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white tabular-nums">
                      8 Skills
                    </h3>
                    <p className="text-[11px] sm:text-xs text-slate-500 dark:text-slate-400 font-medium">
                      {t.statTools}
                    </p>
                  </div>
                  <div>
                    <h3 className="text-lg sm:text-2xl font-extrabold text-primary truncate">
                      @ebrupyaar
                    </h3>
                    <p className="text-[11px] sm:text-xs text-slate-500 dark:text-slate-400 font-medium">
                      {t.statSocial}
                    </p>
                  </div>
                </div>
              </div>

              {/* Hero Visual Card */}
              <div className="lg:col-span-5 relative">
                <div className="relative mx-auto max-w-md lg:max-w-none">
                  <div className="absolute -inset-2 bg-gradient-to-r from-primary to-indigo-500 rounded-3xl blur-xl opacity-20" />
                  <div className="relative glass-card rounded-3xl p-5 sm:p-6 shadow-2xl">
                    <div className="aspect-video rounded-2xl overflow-hidden bg-slate-900 relative group">
                      <img
                        src={HERO_SHOWREEL_ART}
                        alt="Ebrupyaar Featured Work"
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-transparent to-transparent flex items-end p-4 sm:p-5">
                        <div>
                          <span className="text-xs font-semibold text-purple-300">
                            @ebrupyaar
                          </span>
                          <h4 className="text-white font-bold text-sm sm:text-lg mt-0.5">
                            {t.heroCardTitle}
                          </h4>
                        </div>
                      </div>
                    </div>

                    <div className="mt-4 sm:mt-5 space-y-3">
                      <div className="flex items-center justify-between text-[11px] sm:text-xs">
                        <span className="font-semibold text-slate-700 dark:text-slate-200">
                          {t.heroCardTools}
                        </span>
                        <div className="flex space-x-2 text-primary shrink-0 ml-2">
                          <Box className="w-3.5 h-3.5" />
                          <Film className="w-3.5 h-3.5" />
                          <FileText className="w-3.5 h-3.5" />
                        </div>
                      </div>
                      <div className="w-full bg-purple-100 dark:bg-slate-800 rounded-full h-2 overflow-hidden">
                        <div className="bg-gradient-to-r from-primary to-purple-400 h-2 rounded-full w-full" />
                      </div>
                      <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                        <span>Ebrupyaar Portfolio</span>
                        <span className="text-primary font-semibold">
                          @ebrupyaar
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* TOOLS & SERVICES BADGES SECTION (All 8 Specialties) */}
        <section
          id="skills"
          className="py-12 sm:py-16 bg-white/80 dark:bg-darkCard/80 backdrop-blur-sm border-y border-purple-100 dark:border-slate-800"
        >
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-8">
              <h2 className="text-xs font-bold uppercase tracking-widest text-slate-400 dark:text-slate-500">
                {t.toolsHeading}
              </h2>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5 sm:gap-5">
              {toolsCards.map((tool) => (
                <button
                  key={tool.category}
                  type="button"
                  onClick={() => handleFilterAndScroll(tool.category)}
                  className="cursor-pointer flex items-center space-x-3 p-3.5 sm:p-4 rounded-2xl bg-[#F9F8FF] dark:bg-slate-900/70 border border-purple-100 dark:border-slate-800 hover:border-primary transition text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
                >
                  <div
                    className={`w-10 h-10 rounded-xl ${tool.badgeClass} flex items-center justify-center font-bold text-base sm:text-lg shrink-0`}
                  >
                    {tool.badge}
                  </div>
                  <div className="text-left min-w-0">
                    <h4 className="text-xs sm:text-sm font-bold text-slate-800 dark:text-white truncate">
                      {tool.title}
                    </h4>
                    <span className="text-[11px] sm:text-xs text-slate-500 dark:text-slate-400 block truncate">
                      {tool.subtitle}
                    </span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </section>

        {/* PORTFOLIO SHOWCASE SECTION (4-Column Grid + Load More / Show Less) */}
        <section id="portfolio" className="py-16 sm:py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col lg:flex-row lg:items-end justify-between mb-10">
              <div>
                <span className="text-primary font-bold text-xs sm:text-sm tracking-wider uppercase">
                  {t.gallerySub}
                </span>
                <h2 className="text-2xl sm:text-4xl font-extrabold text-slate-900 dark:text-white mt-1 [text-wrap:balance]">
                  {t.galleryTitle}
                </h2>
              </div>

              {/* Touch-Friendly Category Filter Buttons */}
              <div className="flex flex-wrap gap-2 mt-5 lg:mt-0">
                <button
                  type="button"
                  onClick={() => handleFilterChange('All')}
                  className={`px-3.5 py-2 text-xs font-semibold rounded-xl transition whitespace-nowrap shrink-0 cursor-pointer ${
                    currentFilter === 'All'
                      ? 'bg-primary text-white shadow-sm'
                      : 'bg-white dark:bg-darkCard text-slate-600 dark:text-slate-300 hover:bg-purple-50 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700'
                  }`}
                >
                  {t.filterAll}
                </button>
                {PROJECT_CATEGORIES.map((category) => (
                  <button
                    key={category}
                    type="button"
                    onClick={() => handleFilterChange(category)}
                    className={`px-3.5 py-2 text-xs font-semibold rounded-xl transition whitespace-nowrap shrink-0 cursor-pointer ${
                      currentFilter === category
                        ? 'bg-primary text-white shadow-sm'
                        : 'bg-white dark:bg-darkCard text-slate-600 dark:text-slate-300 hover:bg-purple-50 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700'
                    }`}
                  >
                    {category}
                  </button>
                ))}
              </div>
            </div>

            {/* 4-Column Responsive Projects Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {visibleItems.length === 0 ? (
                <div className="col-span-full py-12 text-center text-slate-400">
                  <FolderOpen className="w-10 h-10 mx-auto mb-3 text-slate-300 dark:text-slate-600" />
                  <p className="text-sm font-medium">
                    No projects found in this category.
                  </p>
                </div>
              ) : (
                visibleItems.map((item) => {
                  const mediaInfo = parseMediaUrl(item.url, item.mediaAspect);
                  return (
                    <article
                      key={item.id}
                      className="group bg-white dark:bg-darkCard rounded-3xl overflow-hidden border border-purple-100/80 dark:border-slate-800 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between"
                    >
                      <div>
                        <div
                          role="button"
                          tabIndex={0}
                          onClick={() => setLightboxProject(item)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter' || e.key === ' ') {
                              e.preventDefault();
                              setLightboxProject(item);
                            }
                          }}
                          className="cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
                        >
                          <MediaCardPreview
                            url={item.url}
                            title={item.title}
                            mediaAspect={item.mediaAspect}
                          />
                        </div>
                        <div className="p-5">
                          <div className="text-xs font-semibold text-primary dark:text-purple-300 mb-1.5 flex items-center gap-1.5">
                            <span>{item.category}</span>
                          </div>
                          <h3
                            onClick={() => setLightboxProject(item)}
                            className="font-bold text-base text-slate-900 dark:text-white group-hover:text-primary transition cursor-pointer line-clamp-1"
                          >
                            {item.title}
                          </h3>
                          <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 line-clamp-2 leading-relaxed">
                            {item.desc}
                          </p>
                        </div>
                      </div>
                      <div className="px-5 pb-5 pt-3.5 flex items-center justify-between border-t border-slate-100 dark:border-slate-800 mt-2">
                        <button
                          type="button"
                          onClick={() => setLightboxProject(item)}
                          className="text-xs font-bold text-primary dark:text-purple-400 hover:text-primary-dark flex items-center space-x-1.5 whitespace-nowrap shrink-0 cursor-pointer"
                        >
                          <span>
                            {mediaInfo.isVideo
                              ? t.watchVideoBtn
                              : t.viewProjectBtn}
                          </span>
                          <ArrowRight className="w-3 h-3" />
                        </button>
                        {isAdminUnlocked ? (
                          <button
                            type="button"
                            onClick={() => handleDeleteProject(item.id)}
                            title="Delete Project"
                            aria-label={`Delete ${item.title}`}
                            className="text-slate-400 hover:text-rose-500 text-xs transition p-1 cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        ) : (
                          <span className="text-[11px] font-medium text-slate-400">
                            @ebrupyaar
                          </span>
                        )}
                      </div>
                    </article>
                  );
                })
              )}
            </div>

            {/* Load More / Show Less Toggle Bar */}
            {filteredItems.length > INITIAL_VISIBLE_COUNT && (
              <div className="mt-10 text-center">
                <button
                  type="button"
                  onClick={() => setShowAllProjects((prev) => !prev)}
                  className="inline-flex items-center space-x-2 px-7 py-3.5 rounded-2xl bg-white dark:bg-darkCard text-primary dark:text-purple-300 font-bold text-sm border border-purple-200 dark:border-slate-700 hover:bg-primary hover:text-white dark:hover:bg-primary dark:hover:text-white transition shadow-md cursor-pointer"
                >
                  <span>
                    {showAllProjects
                      ? t.showLess
                      : `${t.loadMore} (+${remainingCount})`}
                  </span>
                  {showAllProjects ? (
                    <ChevronUp className="w-4 h-4" />
                  ) : (
                    <ChevronDown className="w-4 h-4" />
                  )}
                </button>
              </div>
            )}
          </div>
        </section>

        {/* ABOUT SECTION */}
        <section
          id="about"
          className="py-16 sm:py-20 bg-white/80 dark:bg-darkCard/80 backdrop-blur-sm border-t border-purple-100 dark:border-slate-800"
        >
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
              <div className="lg:col-span-5">
                <div className="aspect-square rounded-3xl overflow-hidden bg-purple-100 dark:bg-slate-800 relative shadow-xl border border-purple-200 dark:border-slate-700 max-w-sm sm:max-w-md mx-auto">
                  <img
                    src={ABOUT_STUDIO_ART}
                    alt="Ebrupyaar Profile"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
              <div className="lg:col-span-7 space-y-5 text-center lg:text-left">
                <span className="text-primary font-bold text-xs sm:text-sm tracking-wider uppercase">
                  {t.aboutSub}
                </span>
                <h2 className="text-2xl sm:text-4xl font-extrabold text-slate-900 dark:text-white [text-wrap:balance]">
                  {t.aboutTitle}
                </h2>
                <p className="text-slate-600 dark:text-slate-300 leading-relaxed text-sm sm:text-base">
                  {t.aboutP1}
                </p>
                <p className="text-slate-600 dark:text-slate-300 leading-relaxed text-sm sm:text-base">
                  {t.aboutP2}
                </p>
                <div className="pt-4 flex flex-wrap items-center justify-center lg:justify-start gap-6">
                  <div>
                    <h4 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white">
                      @ebrupyaar
                    </h4>
                    <span className="text-xs text-slate-500 dark:text-slate-400">
                      {t.aboutHandleLabel}
                    </span>
                  </div>
                  <div className="h-8 w-px bg-slate-200 dark:bg-slate-700" />
                  <div>
                    <h4 className="text-xl sm:text-2xl font-extrabold text-primary tabular-nums">
                      100%
                    </h4>
                    <span className="text-xs text-slate-500 dark:text-slate-400">
                      {t.aboutQualityLabel}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* CONTACT & SOCIAL MEDIA SECTION (@ebrupyaar) */}
        <section id="contact" className="py-16 sm:py-20">
          <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="glass-card rounded-3xl p-6 sm:p-12 shadow-xl text-center space-y-6">
              <span className="text-primary dark:text-purple-300 text-xs font-bold uppercase tracking-wider block">
                {t.contactSub}
              </span>
              <h2 className="text-2xl sm:text-4xl font-extrabold text-slate-900 dark:text-white [text-wrap:balance]">
                {t.contactTitle}
              </h2>
              <p className="text-slate-600 dark:text-slate-300 max-w-xl mx-auto text-sm sm:text-base">
                {t.contactDesc}
              </p>

              {/* Copy Handle Button */}
              <div className="flex justify-center">
                <button
                  type="button"
                  onClick={handleCopyHandle}
                  className="inline-flex items-center space-x-2.5 px-5 py-2.5 rounded-2xl bg-purple-50 dark:bg-slate-800 text-primary dark:text-purple-300 border border-purple-200 dark:border-slate-700 hover:bg-purple-100 dark:hover:bg-slate-700 transition font-bold text-sm cursor-pointer"
                >
                  <span>@ebrupyaar</span>
                  <Copy className="w-4 h-4" />
                </button>
              </div>

              {/* Social Media Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3.5 sm:gap-4 pt-4">
                {SOCIAL_LINKS.map((social) => (
                  <a
                    key={social.id}
                    href={social.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`flex flex-col items-center justify-center p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 ${social.hoverBorderClass} hover:-translate-y-1 transition shadow-sm group ${
                      social.id === 'youtube' ? 'col-span-2 sm:col-span-1' : ''
                    }`}
                  >
                    <SocialIcon
                      id={social.id}
                      className={`w-6 h-6 ${social.iconColorClass} mb-2 group-hover:scale-110 transition`}
                    />
                    <span className="text-xs font-bold text-slate-800 dark:text-white">
                      {social.name}
                    </span>
                    <span className="text-[11px] text-slate-400">
                      @ebrupyaar
                    </span>
                  </a>
                ))}
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* FOOTER */}
      <footer className="bg-slate-900 dark:bg-black text-slate-400 py-10 border-t border-slate-800 relative z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-6 md:space-y-0">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center text-white font-bold">
                <PenTool className="w-4 h-4" />
              </div>
              <span className="text-lg font-bold text-white">
                Ebrupyaar Portfolio
              </span>
            </div>
            <div className="flex space-x-6 text-white">
              {SOCIAL_LINKS.map((social) => (
                <a
                  key={social.id}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  title={social.ariaLabel}
                  aria-label={social.ariaLabel}
                  className="hover:text-primary transition"
                >
                  <SocialIcon id={social.id} className="w-5 h-5" />
                </a>
              ))}
            </div>
            <p className="text-xs text-slate-500 text-center">
              {t.footerCopy}
            </p>
          </div>
        </div>
      </footer>

      <PinModal
        isOpen={pinModalOpen}
        t={t}
        onClose={() => setPinModalOpen(false)}
        onSuccess={handlePinSuccess}
      />

      <AdminUploadModal
        isOpen={adminModalOpen}
        onClose={() => setAdminModalOpen(false)}
        onLock={handleLockAdmin}
        onPublish={handlePublishProject}
      />

      <LightboxModal
        project={lightboxProject}
        onClose={() => setLightboxProject(null)}
      />
    </div>
  );
}
