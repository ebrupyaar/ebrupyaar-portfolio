import type { MediaAspect } from '../utils/media';

export type Language = 'en' | 'am';
export type Theme = 'light' | 'dark';

export type ProjectCategory =
  | 'Photoshop'
  | 'Illustrator'
  | 'After Effects'
  | 'Premiere Pro'
  | 'Blender'
  | 'Canva'
  | 'Figma'
  | 'CV Creator';

export type FilterCategory = 'All' | ProjectCategory;

export interface Project {
  id: string;
  title: string;
  category: ProjectCategory;
  url: string;
  desc: string;
  mediaAspect?: MediaAspect;
}

export const ADMIN_PIN = '252525';
export const INITIAL_VISIBLE_COUNT = 4;
export const STORAGE_PROJECTS_KEY = 'ebrupyaar_portfolio_v2';
export const STORAGE_LANG_KEY = 'ebrupyaar_lang';
export const STORAGE_THEME_KEY = 'ebrupyaar_theme';

export const PROJECT_CATEGORIES: ProjectCategory[] = [
  'Photoshop',
  'Illustrator',
  'After Effects',
  'Premiere Pro',
  'Blender',
  'Canva',
  'Figma',
  'CV Creator',
];

function svgToDataUrl(svg: string): string {
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg.trim())}`;
}

export const FALLBACK_PROJECT_ART = svgToDataUrl(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 600" fill="none">
  <defs>
    <linearGradient id="fb" x1="0" y1="0" x2="800" y2="600" gradientUnits="userSpaceOnUse">
      <stop offset="0%" stop-color="#6D4AFF"/>
      <stop offset="100%" stop-color="#312E81"/>
    </linearGradient>
  </defs>
  <rect width="800" height="600" fill="url(#fb)"/>
  <circle cx="400" cy="270" r="90" stroke="white" stroke-opacity="0.25" stroke-width="2" stroke-dasharray="8 8"/>
  <rect x="355" y="225" width="90" height="90" rx="18" stroke="white" stroke-opacity="0.5" stroke-width="2" transform="rotate(15 400 270)"/>
  <text x="400" y="420" text-anchor="middle" fill="white" font-family="sans-serif" font-size="28" font-weight="700">Ebrupyaar Studio</text>
  <text x="400" y="454" text-anchor="middle" fill="white" fill-opacity="0.7" font-family="sans-serif" font-size="16">@ebrupyaar</text>
</svg>
`);

export const HERO_SHOWREEL_ART = svgToDataUrl(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 960 540" fill="none">
  <defs>
    <linearGradient id="hsBg" x1="0" y1="0" x2="960" y2="540" gradientUnits="userSpaceOnUse">
      <stop offset="0%" stop-color="#141029"/>
      <stop offset="55%" stop-color="#2B1B66"/>
      <stop offset="100%" stop-color="#5835EB"/>
    </linearGradient>
    <radialGradient id="hsGlow" cx="0.65" cy="0.35" r="0.5">
      <stop offset="0%" stop-color="#A78BFA" stop-opacity="0.55"/>
      <stop offset="100%" stop-color="#6D4AFF" stop-opacity="0"/>
    </radialGradient>
  </defs>
  <rect width="960" height="540" fill="url(#hsBg)"/>
  <rect width="960" height="540" fill="url(#hsGlow)"/>
  <g stroke="white" stroke-opacity="0.08" stroke-width="1">
    <line x1="0" y1="135" x2="960" y2="135"/>
    <line x1="0" y1="270" x2="960" y2="270"/>
    <line x1="0" y1="405" x2="960" y2="405"/>
    <line x1="240" y1="0" x2="240" y2="540"/>
    <line x1="480" y1="0" x2="480" y2="540"/>
    <line x1="720" y1="0" x2="720" y2="540"/>
  </g>
  <!-- 3D Isometric Cube & Bezier Motif -->
  <g transform="translate(560, 120)">
    <polygon points="120,0 224,60 120,120 16,60" fill="#A78BFA" fill-opacity="0.35" stroke="#E9D5FF" stroke-width="2"/>
    <polygon points="16,60 120,120 120,240 16,180" fill="#6D4AFF" fill-opacity="0.6" stroke="#C4B5FD" stroke-width="2"/>
    <polygon points="224,60 224,180 120,240 120,120" fill="#4C1D95" fill-opacity="0.8" stroke="#C4B5FD" stroke-width="2"/>
  </g>
  <!-- Vector Bezier Curve -->
  <path d="M80 370 C 200 140, 380 420, 560 180" stroke="#DDD6FE" stroke-width="3" stroke-linecap="round"/>
  <line x1="80" y1="370" x2="200" y2="140" stroke="#A78BFA" stroke-width="1.5" stroke-dasharray="5 5"/>
  <line x1="560" y1="180" x2="380" y2="420" stroke="#A78BFA" stroke-width="1.5" stroke-dasharray="5 5"/>
  <circle cx="80" cy="370" r="7" fill="#6D4AFF" stroke="white" stroke-width="2.5"/>
  <circle cx="560" cy="180" r="7" fill="#6D4AFF" stroke="white" stroke-width="2.5"/>
  <rect x="195" y="135" width="10" height="10" fill="white"/>
  <rect x="375" y="415" width="10" height="10" fill="white"/>
  <!-- Timeline Bar -->
  <rect x="80" y="92" width="320" height="10" rx="5" fill="white" fill-opacity="0.16"/>
  <rect x="80" y="92" width="190" height="10" rx="5" fill="#A78BFA"/>
  <rect x="80" y="114" width="240" height="8" rx="4" fill="white" fill-opacity="0.12"/>
  <rect x="130" y="114" width="140" height="8" rx="4" fill="#38BDF8" fill-opacity="0.7"/>
  <!-- Title Overlay -->
  <text x="80" y="230" fill="white" font-family="sans-serif" font-size="44" font-weight="800" letter-spacing="-1">CREATIVE</text>
  <text x="80" y="280" fill="#DDD6FE" font-family="sans-serif" font-size="44" font-weight="800" letter-spacing="-1">SHOWREEL</text>
</svg>
`);

export const ABOUT_STUDIO_ART = svgToDataUrl(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 600" fill="none">
  <defs>
    <linearGradient id="abBg" x1="0" y1="0" x2="600" y2="600" gradientUnits="userSpaceOnUse">
      <stop offset="0%" stop-color="#3B0764"/>
      <stop offset="50%" stop-color="#6D4AFF"/>
      <stop offset="100%" stop-color="#4338CA"/>
    </linearGradient>
  </defs>
  <rect width="600" height="600" fill="url(#abBg)"/>
  <circle cx="300" cy="275" r="190" stroke="white" stroke-opacity="0.16" stroke-width="1.5" stroke-dasharray="8 8"/>
  <circle cx="300" cy="275" r="136" fill="white" fill-opacity="0.08" stroke="white" stroke-opacity="0.24" stroke-width="1.5"/>
  <!-- Pen Nib Emblem -->
  <path d="M300 165 L355 280 L325 350 L275 350 L245 280 Z" fill="white" fill-opacity="0.92"/>
  <line x1="300" y1="165" x2="300" y2="275" stroke="#6D4AFF" stroke-width="4" stroke-linecap="round"/>
  <circle cx="300" cy="285" r="12" fill="#6D4AFF"/>
  <rect x="268" y="358" width="64" height="18" rx="6" fill="#DDD6FE"/>
  <!-- Orbiting Nodes -->
  <circle cx="155" cy="175" r="10" fill="#38BDF8"/>
  <circle cx="455" cy="200" r="8" fill="#FBBF24"/>
  <circle cx="430" cy="390" r="12" fill="#34D399"/>
  <text x="300" y="458" text-anchor="middle" fill="white" font-family="sans-serif" font-size="30" font-weight="800" letter-spacing="-0.5">Ebrupyaar Studio</text>
  <text x="300" y="492" text-anchor="middle" fill="#E9D5FF" font-family="sans-serif" font-size="16" font-weight="600">Graphic • 3D • Motion • CV</text>
</svg>
`);

export const DEFAULT_PROJECTS: Project[] = [
  {
    id: 'p1',
    title: 'Cyberpunk Neon Street Manipulation',
    category: 'Photoshop',
    url: svgToDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 600" fill="none">
        <defs>
          <linearGradient id="p1g" x1="0" y1="0" x2="800" y2="600" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stop-color="#0F0728"/>
            <stop offset="55%" stop-color="#4C1D95"/>
            <stop offset="100%" stop-color="#6D4AFF"/>
          </linearGradient>
        </defs>
        <rect width="800" height="600" fill="url(#p1g)"/>
        <path d="M0 460 L260 320 L540 320 L800 460 L800 600 L0 600 Z" fill="#1E1B4B" fill-opacity="0.85"/>
        <line x1="400" y1="320" x2="400" y2="600" stroke="#38BDF8" stroke-width="3" stroke-dasharray="18 14"/>
        <rect x="130" y="130" width="110" height="210" rx="8" fill="#312E81" stroke="#38BDF8" stroke-width="3"/>
        <rect x="550" y="100" width="130" height="240" rx="8" fill="#3B0764" stroke="#F472B6" stroke-width="3"/>
        <circle cx="400" cy="210" r="88" fill="#EC4899" fill-opacity="0.22" stroke="#F472B6" stroke-width="3"/>
        <text x="400" y="218" text-anchor="middle" fill="white" font-family="sans-serif" font-size="26" font-weight="800">NEON COMPOSITE</text>
        <text x="400" y="530" text-anchor="middle" fill="#C4B5FD" font-family="sans-serif" font-size="16" font-weight="600">Adobe Photoshop · Photo Manipulation</text>
      </svg>
    `),
    desc: 'Advanced digital photo manipulation featuring custom neon lighting, atmospheric depth, and color grading in Adobe Photoshop.',
  },
  {
    id: 'p2',
    title: 'Modern Brand Identity & Vector Logo',
    category: 'Illustrator',
    url: svgToDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 600" fill="none">
        <rect width="800" height="600" fill="#2E1065"/>
        <g stroke="#A78BFA" stroke-opacity="0.18" stroke-width="1">
          <circle cx="400" cy="260" r="150"/>
          <circle cx="400" cy="260" r="100"/>
          <line x1="200" y1="260" x2="600" y2="260"/>
          <line x1="400" y1="60" x2="400" y2="460"/>
          <line x1="260" y1="120" x2="540" y2="400"/>
          <line x1="540" y1="120" x2="260" y2="400"/>
        </g>
        <path d="M400 135 L495 260 L400 385 L305 260 Z" fill="#F59E0B" fill-opacity="0.88"/>
        <circle cx="400" cy="260" r="44" fill="#2E1065" stroke="#FEF3C7" stroke-width="6"/>
        <text x="400" y="485" text-anchor="middle" fill="white" font-family="sans-serif" font-size="24" font-weight="800">GEOMETRIC BRAND SYSTEM</text>
        <text x="400" y="518" text-anchor="middle" fill="#DDD6FE" font-family="sans-serif" font-size="15" font-weight="600">Adobe Illustrator · Vector Grid</text>
      </svg>
    `),
    desc: 'Clean geometric vector brand mark and typography system crafted in Adobe Illustrator.',
  },
  {
    id: 'p3',
    title: 'Dynamic Logo Reveal & Motion Reel',
    category: 'After Effects',
    url: svgToDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 600" fill="none">
        <rect width="800" height="600" fill="#1E1B4B"/>
        <circle cx="400" cy="240" r="130" stroke="#818CF8" stroke-width="3" stroke-dasharray="22 10"/>
        <circle cx="400" cy="240" r="95" stroke="#C084FC" stroke-width="5"/>
        <polygon points="375,195 450,240 375,285" fill="white"/>
        <!-- Keyframe Diamond Timeline -->
        <line x1="120" y1="450" x2="680" y2="450" stroke="#6366F1" stroke-width="3"/>
        <rect x="210" y="440" width="20" height="20" transform="rotate(45 220 450)" fill="#38BDF8"/>
        <rect x="390" y="440" width="20" height="20" transform="rotate(45 400 450)" fill="#C084FC"/>
        <rect x="570" y="440" width="20" height="20" transform="rotate(45 580 450)" fill="#34D399"/>
        <text x="400" y="525" text-anchor="middle" fill="#E0E7FF" font-family="sans-serif" font-size="18" font-weight="700">After Effects · Keyframe Motion Reel</text>
      </svg>
    `),
    desc: 'Smooth shape layer animation, kinetic typography, and sound-synced transitions created in Adobe After Effects.',
  },
  {
    id: 'p4',
    title: 'Cinematic Commercial Promo Edit',
    category: 'Premiere Pro',
    url: svgToDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 600" fill="none">
        <rect width="800" height="600" fill="#0F172A"/>
        <rect x="90" y="90" width="620" height="290" rx="16" fill="#1E1B4B" stroke="#6366F1" stroke-width="2"/>
        <!-- Waveform & Video Tracks -->
        <rect x="90" y="410" width="380" height="32" rx="6" fill="#6D4AFF"/>
        <rect x="482" y="410" width="228" height="32" rx="6" fill="#8B5CF6"/>
        <rect x="90" y="454" width="260" height="26" rx="6" fill="#0EA5E9" fill-opacity="0.8"/>
        <rect x="362" y="454" width="348" height="26" rx="6" fill="#10B981" fill-opacity="0.75"/>
        <line x1="395" y1="80" x2="395" y2="495" stroke="#F43F5E" stroke-width="2.5"/>
        <polygon points="387,80 403,80 395,94" fill="#F43F5E"/>
        <text x="400" y="232" text-anchor="middle" fill="white" font-family="sans-serif" font-size="30" font-weight="800">COMMERCIAL CUT</text>
        <text x="400" y="268" text-anchor="middle" fill="#A5B4FC" font-family="sans-serif" font-size="16" font-weight="600">Color Grading & Multi-Track Audio</text>
      </svg>
    `),
    desc: 'High-energy commercial video editing with color grading, speed ramps, and crisp audio mixing in Adobe Premiere Pro.',
  },
  {
    id: 'p5',
    title: '3D Isometric Studio & Product Render',
    category: 'Blender',
    url: svgToDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 600" fill="none">
        <defs>
          <linearGradient id="b3d" x1="0" y1="0" x2="800" y2="600" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stop-color="#431407"/>
            <stop offset="100%" stop-color="#9A3412"/>
          </linearGradient>
        </defs>
        <rect width="800" height="600" fill="url(#b3d)"/>
        <ellipse cx="400" cy="410" rx="210" ry="60" fill="black" fill-opacity="0.28"/>
        <g transform="translate(270, 120)">
          <polygon points="130,0 260,75 130,150 0,75" fill="#FDBA74"/>
          <polygon points="0,75 130,150 130,290 0,215" fill="#EA580C"/>
          <polygon points="260,75 260,215 130,290 130,150" fill="#9A3412"/>
          <circle cx="130" cy="75" r="34" fill="#FFF7ED" fill-opacity="0.9"/>
        </g>
        <text x="400" y="520" text-anchor="middle" fill="#FFEDD5" font-family="sans-serif" font-size="20" font-weight="700">Blender 3D · Cycles Studio Lighting</text>
      </svg>
    `),
    desc: 'Photorealistic 3D product modeling, custom shaders, and Cycles studio lighting rendered in Blender.',
  },
  {
    id: 'p6',
    title: 'Executive Modern Resume & CV Template',
    category: 'CV Creator',
    url: svgToDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 600" fill="none">
        <rect width="800" height="600" fill="#064E3B"/>
        <rect x="210" y="65" width="380" height="470" rx="14" fill="white"/>
        <rect x="210" y="65" width="130" height="470" rx="14" fill="#047857"/>
        <circle cx="275" cy="140" r="36" fill="#A7F3D0"/>
        <rect x="235" y="200" width="80" height="10" rx="5" fill="#6EE7B7"/>
        <rect x="235" y="224" width="64" height="8" rx="4" fill="#A7F3D0" fill-opacity="0.6"/>
        <rect x="235" y="264" width="80" height="8" rx="4" fill="#A7F3D0" fill-opacity="0.6"/>
        <rect x="235" y="284" width="72" height="8" rx="4" fill="#A7F3D0" fill-opacity="0.6"/>
        <rect x="370" y="110" width="175" height="16" rx="6" fill="#0F172A"/>
        <rect x="370" y="138" width="120" height="10" rx="5" fill="#10B981"/>
        <rect x="370" y="185" width="185" height="10" rx="5" fill="#CBD5E1"/>
        <rect x="370" y="207" width="160" height="10" rx="5" fill="#CBD5E1"/>
        <rect x="370" y="229" width="170" height="10" rx="5" fill="#CBD5E1"/>
        <rect x="370" y="275" width="145" height="12" rx="6" fill="#334155"/>
        <rect x="370" y="302" width="185" height="10" rx="5" fill="#CBD5E1"/>
        <rect x="370" y="324" width="165" height="10" rx="5" fill="#CBD5E1"/>
        <rect x="370" y="370" width="145" height="12" rx="6" fill="#334155"/>
        <rect x="370" y="398" width="185" height="10" rx="5" fill="#CBD5E1"/>
      </svg>
    `),
    desc: 'Clean, ATS-friendly, and visually striking professional CV layout tailored to help candidates stand out.',
  },
  {
    id: 'p7',
    title: 'Mobile App UI / UX Design System',
    category: 'Figma',
    url: svgToDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 600" fill="none">
        <rect width="800" height="600" fill="#3B0764"/>
        <rect x="175" y="95" width="200" height="410" rx="28" fill="#181B24" stroke="#A855F7" stroke-width="3"/>
        <rect x="195" y="135" width="160" height="90" rx="14" fill="#6D4AFF"/>
        <rect x="195" y="242" width="74" height="74" rx="12" fill="#2E1065" stroke="#8B5CF6" stroke-width="1.5"/>
        <rect x="281" y="242" width="74" height="74" rx="12" fill="#2E1065" stroke="#8B5CF6" stroke-width="1.5"/>
        <rect x="195" y="332" width="160" height="44" rx="10" fill="#27272A"/>
        <rect x="195" y="390" width="160" height="44" rx="10" fill="#27272A"/>
        <rect x="425" y="130" width="210" height="340" rx="22" fill="#F9F8FF"/>
        <rect x="448" y="160" width="164" height="28" rx="8" fill="#6D4AFF"/>
        <rect x="448" y="206" width="164" height="92" rx="12" fill="#EDE9FE"/>
        <rect x="448" y="316" width="164" height="16" rx="8" fill="#CBD5E1"/>
        <rect x="448" y="344" width="120" height="16" rx="8" fill="#CBD5E1"/>
        <rect x="448" y="390" width="164" height="42" rx="12" fill="#6D4AFF"/>
      </svg>
    `),
    desc: 'Interactive mobile interface prototype with clean violet accents and user-friendly navigation in Figma.',
  },
  {
    id: 'p8',
    title: 'Social Media Campaign & Promo Pack',
    category: 'Canva',
    url: svgToDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 600" fill="none">
        <defs>
          <linearGradient id="cnv" x1="0" y1="0" x2="800" y2="600" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stop-color="#5B21B6"/>
            <stop offset="100%" stop-color="#0D9488"/>
          </linearGradient>
        </defs>
        <rect width="800" height="600" fill="url(#cnv)"/>
        <rect x="115" y="110" width="175" height="380" rx="18" fill="white" fill-opacity="0.94"/>
        <rect x="312" y="85" width="176" height="430" rx="18" fill="#0F172A"/>
        <rect x="510" y="110" width="175" height="380" rx="18" fill="white" fill-opacity="0.94"/>
        <rect x="334" y="120" width="132" height="132" rx="14" fill="#6D4AFF"/>
        <text x="400" y="305" text-anchor="middle" fill="white" font-family="sans-serif" font-size="22" font-weight="800">@EBRUPYAAR</text>
        <text x="400" y="335" text-anchor="middle" fill="#5EEAD4" font-family="sans-serif" font-size="14" font-weight="600">CAROUSEL PACK</text>
        <rect x="135" y="140" width="135" height="120" rx="12" fill="#DDD6FE"/>
        <rect x="530" y="140" width="135" height="120" rx="12" fill="#CCFBF1"/>
      </svg>
    `),
    desc: 'High-converting social media carousel and promotional templates designed in Canva for @ebrupyaar.',
  },
  {
    id: 'p9',
    title: 'Creative Tech Specialist CV Portfolio',
    category: 'CV Creator',
    url: svgToDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 600" fill="none">
        <rect width="800" height="600" fill="#134E4A"/>
        <rect x="190" y="65" width="420" height="470" rx="16" fill="#F8FAFC"/>
        <rect x="190" y="65" width="420" height="108" rx="16" fill="#0F766E"/>
        <text x="230" y="118" fill="white" font-family="sans-serif" font-size="24" font-weight="800">CREATIVE TECH CV</text>
        <text x="230" y="146" fill="#CCFBF1" font-family="sans-serif" font-size="14" font-weight="600">Two-Column Portfolio Resume</text>
        <!-- Skill Bars -->
        <rect x="230" y="215" width="150" height="10" rx="5" fill="#CBD5E1"/>
        <rect x="230" y="215" width="130" height="10" rx="5" fill="#0D9488"/>
        <rect x="230" y="245" width="150" height="10" rx="5" fill="#CBD5E1"/>
        <rect x="230" y="245" width="115" height="10" rx="5" fill="#0D9488"/>
        <rect x="230" y="275" width="150" height="10" rx="5" fill="#CBD5E1"/>
        <rect x="230" y="275" width="140" height="10" rx="5" fill="#0D9488"/>
        <rect x="420" y="215" width="150" height="12" rx="6" fill="#0F172A"/>
        <rect x="420" y="242" width="150" height="10" rx="5" fill="#CBD5E1"/>
        <rect x="420" y="264" width="135" height="10" rx="5" fill="#CBD5E1"/>
        <rect x="420" y="310" width="150" height="12" rx="6" fill="#0F172A"/>
        <rect x="420" y="338" width="145" height="10" rx="5" fill="#CBD5E1"/>
        <rect x="420" y="360" width="130" height="10" rx="5" fill="#CBD5E1"/>
      </svg>
    `),
    desc: 'Bespoke two-column resume design with custom skill meters and clean typography.',
  },
];

export interface TranslationDict {
  brandSub: string;
  navPortfolio: string;
  navTools: string;
  navAbout: string;
  navContact: string;
  navAdmin: string;
  heroBadge: string;
  heroTitle1: string;
  heroTitle2: string;
  heroDesc: string;
  btnViewWork: string;
  btnHireMe: string;
  statProjects: string;
  statTools: string;
  statSocial: string;
  heroCardTitle: string;
  heroCardTools: string;
  toolsHeading: string;
  toolPs: string;
  toolAi: string;
  toolAe: string;
  toolPr: string;
  toolBlender: string;
  toolCanva: string;
  toolFigma: string;
  toolCvTitle: string;
  toolCv: string;
  gallerySub: string;
  galleryTitle: string;
  filterAll: string;
  loadMore: string;
  showLess: string;
  aboutSub: string;
  aboutTitle: string;
  aboutP1: string;
  aboutP2: string;
  aboutHandleLabel: string;
  aboutQualityLabel: string;
  contactSub: string;
  contactTitle: string;
  contactDesc: string;
  footerCopy: string;
  pinTitle: string;
  pinSubtitle: string;
  pinSubmit: string;
  viewProjectBtn: string;
  watchVideoBtn: string;
}

export const translations: Record<Language, TranslationDict> = {
  en: {
    brandSub: 'Graphic, 3D & Motion',
    navPortfolio: 'Portfolio',
    navTools: 'Tools & Services',
    navAbout: 'About',
    navContact: 'Contact',
    navAdmin: 'Admin',
    heroBadge: 'Ebrupyaar Creative Studio',
    heroTitle1: 'Creative Visuals, 3D &',
    heroTitle2: 'Motion Design.',
    heroDesc:
      'Welcome to Ebrupyaar Portfolio. Explore creative works crafted with Photoshop, Illustrator, After Effects, Premiere Pro, Blender, Canva, Figma, and custom CV Creation.',
    btnViewWork: 'Explore Projects',
    btnHireMe: 'Connect @ebrupyaar',
    statProjects: 'Featured Works',
    statTools: 'Design, 3D & CV',
    statSocial: 'Official Handle',
    heroCardTitle: 'Graphic, Video, 3D & CV Studio',
    heroCardTools: 'Ps • Ai • Ae • Pr • Blender • Canva • Figma • CV',
    toolsHeading: 'Creative Software & Services',
    toolPs: 'Posters & Art',
    toolAi: 'Logos & Vector',
    toolAe: 'Motion & VFX',
    toolPr: 'Video Editing',
    toolBlender: '3D Modeling',
    toolCanva: 'Social Media',
    toolFigma: 'UI / UX Design',
    toolCvTitle: 'CV Creator',
    toolCv: 'Modern Resumes',
    gallerySub: 'Portfolio Gallery',
    galleryTitle: 'Selected Creative Works',
    filterAll: 'All Works',
    loadMore: 'Load More Works',
    showLess: 'Show Less',
    aboutSub: 'About Ebrupyaar',
    aboutTitle: 'Turning Creative Ideas into Visual Impact',
    aboutP1:
      "Hi, I'm Ebrupyaar — a multidisciplinary Graphic Designer, Video Editor, 3D Artist, and CV Creator. I craft eye-catching posters in Photoshop, clean logos in Illustrator, motion graphics in After Effects, cinematic edits in Premiere Pro, 3D renders in Blender, modern UI in Figma & Canva, and executive CVs that get you hired.",
    aboutP2:
      'Browse my latest works above or connect with me across LinkedIn, Telegram, TikTok, Facebook, and YouTube using @ebrupyaar.',
    aboutHandleLabel: 'All Social Media Platforms',
    aboutQualityLabel: 'Creative Dedication',
    contactSub: "Let's Work Together",
    contactTitle: 'Connect with @ebrupyaar',
    contactDesc:
      'Follow my daily creative journey or message me directly on LinkedIn, Telegram, TikTok, Facebook, or YouTube using @ebrupyaar.',
    footerCopy: '© 2026 Ebrupyaar Portfolio (@ebrupyaar). All rights reserved.',
    pinTitle: 'Admin Access',
    pinSubtitle: 'Enter your 6-digit PIN to upload or manage projects.',
    pinSubmit: 'Unlock Admin Panel',
    viewProjectBtn: 'View Project',
    watchVideoBtn: 'Play Video',
  },
  am: {
    brandSub: 'ግራፊክ፣ 3D እና ሞሽን',
    navPortfolio: 'ስራዎቼ',
    navTools: 'ቱሎች እና አገልግሎቶች',
    navAbout: 'ስለ እኔ',
    navContact: 'ያግኙኝ',
    navAdmin: 'አድሚን',
    heroBadge: 'Ebrupyaar ክሬቲቭ ስቱዲዮ',
    heroTitle1: 'ማራኪ ግራፊክስ፣ 3D እና',
    heroTitle2: 'ሞሽን ዲዛይን።',
    heroDesc:
      'እንኳን ወደ Ebrupyaar ፖርትፎሊዮ በደህና መጡ። በ Photoshop፣ Illustrator፣ After Effects፣ Premiere Pro፣ Blender፣ Canva፣ Figma እና ፕሮፌሽናል CV ዝግጅት የተሰሩ ስራዎችን እዚህ ይመልከቱ።',
    btnViewWork: 'ስራዎቼን ይመልከቱ',
    btnHireMe: 'በ @ebrupyaar ያግኙኝ',
    statProjects: 'የተሰሩ ፕሮጀክቶች',
    statTools: 'ዲዛይን፣ 3D እና CV',
    statSocial: 'ኦፊሴላዊ አድራሻ',
    heroCardTitle: 'ግራፊክስ፣ ቪዲዮ፣ 3D እና CV ስቱዲዮ',
    heroCardTools: 'Ps • Ai • Ae • Pr • Blender • Canva • Figma • CV',
    toolsHeading: 'የምጠቀምባቸው ሶፍትዌሮች እና አገልግሎቶች',
    toolPs: 'ፖስተር እና ምስል',
    toolAi: 'ሎጎ እና ቬክተር',
    toolAe: 'ሞሽን እና VFX',
    toolPr: 'ቪዲዮ ኤዲቲንግ',
    toolBlender: '3D ሞዴሊንግ',
    toolCanva: 'ሶሻል ሚዲያ',
    toolFigma: 'UI / UX ዲዛይን',
    toolCvTitle: 'CV አዘጋጅ',
    toolCv: 'ዘመናዊ ሲቪ (Resume)',
    gallerySub: 'የስራዎች ማሳያ',
    galleryTitle: 'የተመረጡ የፈጠራ ስራዎች',
    filterAll: 'ሁሉም ስራዎች',
    loadMore: 'ተጨማሪ ስራዎችን ይመልከቱ',
    showLess: 'ቀንስ (Show Less)',
    aboutSub: 'ስለ Ebrupyaar',
    aboutTitle: 'ሀሳብዎን ወደ ማራኪ ምስል እና ቪዲዮ እንቀይራለን',
    aboutP1:
      'ሰላም፣ Ebrupyaar እባላለሁ። በ Photoshop ፖስተሮችን፣ በ Illustrator ሎጎዎችን፣ በ After Effects ሞሽን ግራፊክስ፣ በ Premiere Pro ቪዲዮ ኤዲቲንግ፣ በ Blender 3D ዲዛይን፣ በ Figma እና Canva ዘመናዊ ዲዛይኖችን እንዲሁም ፕሮፌሽናል CV አዘጋጃለሁ።',
    aboutP2:
      'ከላይ የተዘረዘሩትን ስራዎቼን ይመልከቱ፤ ለስራ ትብብር ወይም ትዕዛዝ በ LinkedIn፣ Telegram፣ TikTok፣ Facebook እና YouTube @ebrupyaar ብለው ያግኙኝ።',
    aboutHandleLabel: 'በሁሉም ሶሻል ሚዲያዎች',
    aboutQualityLabel: 'ጥራት ያለው ስራ',
    contactSub: 'አብረን እንስራ',
    contactTitle: 'በ @ebrupyaar ያግኙኝ',
    contactDesc:
      'የዕለት ተዕለት የዲዛይን ስራዎቼን ለመከታተል ወይም ስራ ለማሰራት በ LinkedIn፣ Telegram፣ TikTok፣ Facebook እና YouTube @ebrupyaar ይጠቀሙ።',
    footerCopy: '© 2026 Ebrupyaar Portfolio (@ebrupyaar). መብቱ በህግ የተጠበቀ ነው።',
    pinTitle: 'የአድሚን መግቢያ',
    pinSubtitle: 'ፕሮጀክቶችን ለመጫን ባለ 6 አሃዝ ሚስጥር ቁጥር (PIN) ያስገቡ።',
    pinSubmit: 'ክፈት (Unlock)',
    viewProjectBtn: 'ስራውን ይመልከቱ',
    watchVideoBtn: 'ቪዲዮውን አጫውት',
  },
};

export interface SocialLinkItem {
  id: 'linkedin' | 'telegram' | 'tiktok' | 'facebook' | 'youtube';
  name: string;
  href: string;
  ariaLabel: string;
  hoverTextClass: string;
  hoverBorderClass: string;
  iconColorClass: string;
}

export const SOCIAL_LINKS: SocialLinkItem[] = [
  {
    id: 'linkedin',
    name: 'LinkedIn',
    href: 'https://linkedin.com/in/ebrupyaar',
    ariaLabel: 'LinkedIn @ebrupyaar',
    hoverTextClass: 'hover:text-blue-600',
    hoverBorderClass: 'hover:border-blue-600',
    iconColorClass: 'text-blue-600',
  },
  {
    id: 'telegram',
    name: 'Telegram',
    href: 'https://t.me/ebrupyaar',
    ariaLabel: 'Telegram @ebrupyaar',
    hoverTextClass: 'hover:text-sky-500',
    hoverBorderClass: 'hover:border-sky-500',
    iconColorClass: 'text-sky-500',
  },
  {
    id: 'tiktok',
    name: 'TikTok',
    href: 'https://tiktok.com/@ebrupyaar',
    ariaLabel: 'TikTok @ebrupyaar',
    hoverTextClass: 'hover:text-primary',
    hoverBorderClass: 'hover:border-primary',
    iconColorClass: 'text-slate-900 dark:text-white',
  },
  {
    id: 'facebook',
    name: 'Facebook',
    href: 'https://facebook.com/ebrupyaar',
    ariaLabel: 'Facebook @ebrupyaar',
    hoverTextClass: 'hover:text-blue-700',
    hoverBorderClass: 'hover:border-blue-700',
    iconColorClass: 'text-blue-700',
  },
  {
    id: 'youtube',
    name: 'YouTube',
    href: 'https://youtube.com/@ebrupyaar',
    ariaLabel: 'YouTube @ebrupyaar',
    hoverTextClass: 'hover:text-red-600',
    hoverBorderClass: 'hover:border-red-600',
    iconColorClass: 'text-red-600',
  },
];
